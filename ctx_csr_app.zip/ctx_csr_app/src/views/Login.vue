<template>
  <div class="login">
    <LanguageSwitcher />
    <p>TEXT ::{{$t('message')}}</p>
  </div>
</template>

<script lang="ts">
import { Options, Vue } from 'vue-class-component';
import LanguageSwitcher from '@/components/language_switcher/LanguageSwitcher.vue'; // @ is an alias to /src
@Options({
  components: {
    LanguageSwitcher
  },
})
export default class Login extends Vue {}
</script>
