<template>
  <div class="register">
    <h1>This is an about page</h1>
    <p>TEXT ::{{$t('message')}}</p>
  </div>
</template>
