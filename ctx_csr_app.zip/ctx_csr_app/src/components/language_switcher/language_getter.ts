const lngGetter = ():string => {
    let lng = localStorage.getItem('ctx_lng');
    if(!lng){
        lng = 'en';
        localStorage.setItem('ctx_lng', lng);
    }
    return lng;
}

export default lngGetter;