<template>
  <div>
    <select v-model="$i18n.locale" v-on:change="set_local">
      <option v-for="(lang, i) in langs" :key="`lang-${i}`" :value="lang" :selected="`${lng_local(lang)}`">
          {{ lang }}
      </option>
    </select>
  </div>
</template>

<script lang="ts">
import { Vue } from 'vue-class-component';
import i18n from '../../i18n'
export default class LanguageSwitcher extends Vue {
  lng_local(lng:string):boolean {
    return localStorage.getItem('ctx_lng') == lng;
  }
  set_local():void {
   localStorage.setItem('ctx_lng', this.$i18n.locale);
  }
  langs =  i18n.global.availableLocales;
}

</script>