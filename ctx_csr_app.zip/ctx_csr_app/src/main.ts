import { createApp } from 'vue'
import App from './App.vue'
import './registerServiceWorker'
import router from './router'
import store from './store'
import i18n from './i18n'
import lngGetter from '@/components/language_switcher/language_getter';
router.beforeEach((to, from, next) => {
    const lng = lngGetter();
    i18n.global.locale = lng.toString();
    next();
});

createApp(App)
    .use(i18n)
    .use(store)
    .use(router)
    .mount('#app')
